EAGLE AutoRouter Statistics:

Job           : D:/Elektrotechnik/Datenbl�tter/Baugruppen/Displays/TFT/TFT 4.58 inch 320x960/Control Board/eagle/ER-PCBA5981.brd

Start at      : 09:35:35 (15.04.2026)
End at        : 09:35:35 (15.04.2026)
Elapsed time  : 00:00:00

Signals       :    61   RoutingGrid: 50 mil  Layers: 2
Connections   :   214   predefined:  179 ( 159 Vias )

Router memory :   8096

Passname          :     Route Optimize1 Optimize2 Optimize3 Optimize4

Time per pass     :  00:00:00  00:00:00  00:00:00  00:00:00  00:00:00
Number of Ripups  :         0         0         0         0         0
max. Level        :         0         0         0         0         0
max. Total        :         0         0         0         0         0

Routed            :         0         0         0         0         0
Vias              :         0         0         0         0         0
Resolution        :    83.6 %    83.6 %    83.6 %    83.6 %    83.6 %

Final             : 99.4% beendet
